package com.example.scorecounting;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    // Global variable
    int currentScore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // In dono lines par red error tabhi ayega agar XML mein ID galat hogi
        TextView tvScore = findViewById(R.id.tvScore);
        Button btnAddRun = findViewById(R.id.btnAddRun);

        // Click logic
        btnAddRun.setOnClickListener(v -> {
            currentScore++;
            tvScore.setText("Score: " + currentScore);
        });
    }
}